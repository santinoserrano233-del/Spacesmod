# Space Mod (tModLoader)

Mod espacial para Terraria con 11 jefes (pre-Hardmode, Hardmode y post-Moon Lord), armas, armaduras y materiales.

## Compilar en tu PC
1. Copia la carpeta `SpaceMod` a `Documentos/My Games/Terraria/tModLoader/ModSources/`.
2. En tModLoader: **Workshop -> Develop Mods -> Build + Reload**.
3. El `.tmod` queda en `.../tModLoader/Mods/SpaceMod.tmod`.

## Compilar en GitHub (Actions)
Cada push a `main` ejecuta `.github/workflows/build.yml` y sube `SpaceMod.tmod` como artefacto
(pestana **Actions** -> ultima ejecucion -> **Artifacts**).
Para publicar una release descargable: `git tag v0.2 && git push --tags`.

## Notas
- Si tu tModLoader es anterior a 2024, cambia `net8.0` por `net6.0` en `SpaceMod/SpaceMod.csproj`.
- Los sprites son placeholders de color; reemplaza los `.png` con arte real (mismo nombre y tamano).
