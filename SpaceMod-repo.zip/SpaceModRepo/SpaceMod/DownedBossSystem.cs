using System.Collections.Generic;
using Terraria.ModLoader;
using Terraria.ModLoader.IO;
namespace SpaceMod
{
    public class DownedBossSystem : ModSystem
    {
        public static HashSet<string> Downed = new HashSet<string>();
        public static bool IsDowned(string bossClassName) => Downed.Contains(bossClassName);
        public override void ClearWorld() { Downed.Clear(); }
        public override void SaveWorldData(TagCompound tag) { tag["downed"] = new List<string>(Downed); }
        public override void LoadWorldData(TagCompound tag) { Downed = new HashSet<string>(tag.GetList<string>("downed")); }
    }
}
