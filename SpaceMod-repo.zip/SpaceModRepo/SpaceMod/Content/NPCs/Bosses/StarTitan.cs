using Terraria.ID; using Terraria.ModLoader;
using SpaceMod.Content.Items;
using SpaceMod.Content.Items.Armor;
namespace SpaceMod.Content.NPCs.Bosses
{
    public class StarTitan : SpaceBoss
    {
        protected override int BaseLife => 140000;
        protected override int BaseDamage => 140;
        protected override int BaseDefense => 45;
        protected override int Size => 150;
        protected override float Speed => 15f;
        protected override int HealItem => ItemID.SuperHealingPotion;
        protected override string[] Attacks => new[] { "Spread", "Ring", "Dash", "Rain" };
        protected override int MaterialType => ModContent.ItemType<TitanHeart>();
        protected override int WeaponType => ModContent.ItemType<TitanBlaster>();
        protected override int HelmetType => ModContent.ItemType<TitanHelmet>();
        protected override int BodyType => ModContent.ItemType<TitanBreastplate>();
        protected override int LegsType => ModContent.ItemType<TitanLeggings>();
    }
}
