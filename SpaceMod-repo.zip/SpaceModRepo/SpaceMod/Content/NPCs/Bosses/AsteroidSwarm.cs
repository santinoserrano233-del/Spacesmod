using Terraria.ID; using Terraria.ModLoader;
using SpaceMod.Content.Items;
using SpaceMod.Content.Items.Armor;
namespace SpaceMod.Content.NPCs.Bosses
{
    public class AsteroidSwarm : SpaceBoss
    {
        protected override int BaseLife => 6500;
        protected override int BaseDamage => 32;
        protected override int BaseDefense => 12;
        protected override int Size => 90;
        protected override float Speed => 11f;
        protected override int HealItem => ItemID.LesserHealingPotion;
        protected override string[] Attacks => new[] { "Ring", "Rain", "Spread" };
        protected override int MaterialType => ModContent.ItemType<AsteroidShard>();
        protected override int WeaponType => ModContent.ItemType<AsteroidBlaster>();
        protected override int HelmetType => ModContent.ItemType<AsteroidHelmet>();
        protected override int BodyType => ModContent.ItemType<AsteroidBreastplate>();
        protected override int LegsType => ModContent.ItemType<AsteroidLeggings>();
    }
}
