using Terraria.ID; using Terraria.ModLoader;
using SpaceMod.Content.Items;
using SpaceMod.Content.Items.Armor;
namespace SpaceMod.Content.NPCs.Bosses
{
    public class NebulaQueen : SpaceBoss
    {
        protected override int BaseLife => 42000;
        protected override int BaseDamage => 80;
        protected override int BaseDefense => 28;
        protected override int Size => 100;
        protected override float Speed => 13f;
        protected override int HealItem => ItemID.GreaterHealingPotion;
        protected override string[] Attacks => new[] { "Spiral", "Ring", "Spread" };
        protected override int MaterialType => ModContent.ItemType<NebulaEssence>();
        protected override int WeaponType => ModContent.ItemType<NebulaStaff>();
        protected override int HelmetType => ModContent.ItemType<NebulaHelmet>();
        protected override int BodyType => ModContent.ItemType<NebulaBreastplate>();
        protected override int LegsType => ModContent.ItemType<NebulaLeggings>();
    }
}
