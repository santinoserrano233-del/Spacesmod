using Terraria.ModLoader;
using SpaceMod.Content.Items;
using SpaceMod.Content.Items.Armor;
namespace SpaceMod.Content.NPCs.Bosses
{
    public class LunarSentinel : SpaceBoss
    {
        protected override int BaseLife => 4200;
        protected override int BaseDamage => 30;
        protected override int BaseDefense => 10;
        protected override string[] Attacks => new[] { "Spread", "Dash" };
        protected override int MaterialType => ModContent.ItemType<LunarFragment>();
        protected override int WeaponType => ModContent.ItemType<LunarBlade>();
        protected override int HelmetType => ModContent.ItemType<LunarHelmet>();
        protected override int BodyType => ModContent.ItemType<LunarBreastplate>();
        protected override int LegsType => ModContent.ItemType<LunarLeggings>();
    }
}
