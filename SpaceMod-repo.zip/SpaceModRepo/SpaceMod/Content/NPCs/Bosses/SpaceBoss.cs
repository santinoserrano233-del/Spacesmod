using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Audio;
using Terraria.GameContent.ItemDropRules;
using Terraria.ID;
using Terraria.ModLoader;
using SpaceMod.Content.Projectiles;

namespace SpaceMod.Content.NPCs.Bosses
{
    // Base compartida: cada jefe solo define estadisticas, ataques y drops.
    // Ataques disponibles: Spread, Dash, Ring, Spiral, Rain, Pull
    public abstract class SpaceBoss : ModNPC
    {
        protected abstract int BaseLife { get; }
        protected abstract int BaseDamage { get; }
        protected abstract int BaseDefense { get; }
        protected abstract string[] Attacks { get; }
        protected abstract int MaterialType { get; }
        protected abstract int WeaponType { get; }
        protected abstract int HelmetType { get; }
        protected abstract int BodyType { get; }
        protected abstract int LegsType { get; }
        protected virtual int HealItem => ItemID.LesserHealingPotion;
        protected virtual int Size => 80;
        protected virtual float Speed => 12f;
        protected int ProjDamage => Math.Max(1, BaseDamage / 2);

        public override void SetStaticDefaults() { Main.npcFrameCount[Type] = 1; }

        public override void SetDefaults()
        {
            NPC.width = Size; NPC.height = Size; NPC.damage = BaseDamage; NPC.defense = BaseDefense; NPC.lifeMax = BaseLife;
            NPC.knockBackResist = 0f; NPC.noGravity = true; NPC.noTileCollide = true; NPC.boss = true;
            NPC.aiStyle = -1; NPC.HitSound = SoundID.NPCHit4; NPC.DeathSound = SoundID.NPCDeath14;
            NPC.value = Item.buyPrice(gold: 3); NPC.npcSlots = 10f;
        }

        public override void ApplyDifficultyAndPlayerScaling(int numPlayers, float balance, float bossAdjustment)
        {
            NPC.lifeMax = (int)(NPC.lifeMax * 0.7f * bossAdjustment);
        }

        // ai[0] = indice de ataque, ai[1] = temporizador
        public override void AI()
        {
            NPC.TargetClosest(true);
            Player p = Main.player[NPC.target];
            if (p.dead || !p.active) { NPC.velocity.Y -= 0.3f; NPC.EncourageDespawn(30); return; }

            bool ph2 = NPC.life < NPC.lifeMax * 0.5f;
            string[] atk = Attacks;
            string cur = atk[(int)NPC.ai[0] % atk.Length];
            NPC.ai[1]++;
            float t = NPC.ai[1];
            bool server = Main.netMode != NetmodeID.MultiplayerClient;

            switch (cur)
            {
                case "Spread":
                    Hover(p, -260f);
                    if (server && t % (ph2 ? 40 : 65) == 0) Fan(p, ph2 ? 7 : 4, 9f);
                    if (t >= 240) Next();
                    break;
                case "Dash":
                    if (t % 50 == 1)
                    {
                        NPC.velocity = (p.Center - NPC.Center).SafeNormalize(Vector2.UnitY) * Speed * (ph2 ? 1.8f : 1.5f);
                        SoundEngine.PlaySound(SoundID.Roar, NPC.Center);
                    }
                    NPC.velocity *= 0.98f;
                    if (t >= 150) Next();
                    break;
                case "Ring":
                    Hover(p, -300f);
                    if (server && t % (ph2 ? 50 : 80) == 0) Ring(ph2 ? 20 : 12, 6f, Main.rand.NextFloat(MathHelper.TwoPi));
                    if (t >= 240) Next();
                    break;
                case "Spiral":
                    Hover(p, -250f);
                    if (server && t % 5 == 0)
                    {
                        NPC.localAI[0] += 0.4f;
                        Shoot(Vector2.UnitX.RotatedBy(NPC.localAI[0]) * 6f);
                        Shoot(Vector2.UnitX.RotatedBy(NPC.localAI[0] + MathHelper.Pi) * 6f);
                        if (ph2) { Shoot(Vector2.UnitX.RotatedBy(NPC.localAI[0] + MathHelper.PiOver2) * 6f); Shoot(Vector2.UnitX.RotatedBy(NPC.localAI[0] - MathHelper.PiOver2) * 6f); }
                    }
                    if (t >= 240) Next();
                    break;
                case "Rain":
                    Hover(p, -400f);
                    if (server && t % (ph2 ? 10 : 18) == 0)
                    {
                        Vector2 pos = p.Center + new Vector2(Main.rand.Next(-700, 700), -550);
                        Projectile.NewProjectile(NPC.GetSource_FromAI(), pos, new Vector2(0, 9f), ModContent.ProjectileType<LunarBolt>(), ProjDamage, 0f, Main.myPlayer);
                    }
                    if (t >= 240) Next();
                    break;
                case "Pull":
                    Hover(p, -200f);
                    if (Main.netMode != NetmodeID.Server)
                    {
                        Player lp = Main.LocalPlayer;
                        if (lp.active && !lp.dead)
                        {
                            Vector2 dd = NPC.Center - lp.Center;
                            if (dd.Length() < 1600f) lp.velocity += dd.SafeNormalize(Vector2.Zero) * 0.25f;
                        }
                    }
                    if (server && t % 90 == 0) Ring(ph2 ? 16 : 10, 5f, 0f);
                    if (t >= 300) Next();
                    break;
                default:
                    Next();
                    break;
            }
            NPC.rotation = NPC.velocity.X * 0.03f;
            Lighting.AddLight(NPC.Center, 0.5f, 0.6f, 1f);
        }

        private void Next() { NPC.ai[0]++; NPC.ai[1] = 0; NPC.netUpdate = true; }

        private void Hover(Player p, float yOff)
        {
            Vector2 d = p.Center + new Vector2(0, yOff) - NPC.Center;
            NPC.velocity = Vector2.Lerp(NPC.velocity, d * 0.04f, 0.1f);
            if (NPC.velocity.Length() > Speed) NPC.velocity = NPC.velocity.SafeNormalize(Vector2.Zero) * Speed;
        }

        private void Shoot(Vector2 vel)
        {
            Projectile.NewProjectile(NPC.GetSource_FromAI(), NPC.Center, vel, ModContent.ProjectileType<LunarBolt>(), ProjDamage, 0f, Main.myPlayer);
        }

        private void Fan(Player p, int n, float speed)
        {
            Vector2 dir = (p.Center - NPC.Center).SafeNormalize(Vector2.UnitY);
            for (int i = 0; i < n; i++)
                Shoot(dir.RotatedBy(MathHelper.ToRadians((i - (n - 1) / 2f) * 11f)) * speed);
            SoundEngine.PlaySound(SoundID.Item8, NPC.Center);
        }

        private void Ring(int n, float speed, float offset)
        {
            for (int i = 0; i < n; i++)
                Shoot(Vector2.UnitX.RotatedBy(offset + MathHelper.TwoPi * i / n) * speed);
            SoundEngine.PlaySound(SoundID.Item122, NPC.Center);
        }

        public override void OnKill() { DownedBossSystem.Downed.Add(GetType().Name); }

        public override void ModifyNPCLoot(NPCLoot npcLoot)
        {
            npcLoot.Add(ItemDropRule.Common(MaterialType, 1, 12, 20));
            npcLoot.Add(ItemDropRule.Common(HealItem, 1, 5, 15));
            npcLoot.Add(ItemDropRule.Common(WeaponType, 2));
            npcLoot.Add(ItemDropRule.Common(HelmetType, 3));
            npcLoot.Add(ItemDropRule.Common(BodyType, 3));
            npcLoot.Add(ItemDropRule.Common(LegsType, 3));
        }
    }
}
