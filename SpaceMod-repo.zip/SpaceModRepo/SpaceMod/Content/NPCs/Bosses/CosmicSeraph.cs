using Terraria.ID; using Terraria.ModLoader;
using SpaceMod.Content.Items;
using SpaceMod.Content.Items.Armor;
namespace SpaceMod.Content.NPCs.Bosses
{
    public class CosmicSeraph : SpaceBoss
    {
        protected override int BaseLife => 240000;
        protected override int BaseDamage => 180;
        protected override int BaseDefense => 55;
        protected override int Size => 130;
        protected override float Speed => 17f;
        protected override int HealItem => ItemID.SuperHealingPotion;
        protected override string[] Attacks => new[] { "Spiral", "Rain", "Dash", "Pull" };
        protected override int MaterialType => ModContent.ItemType<SeraphFeather>();
        protected override int WeaponType => ModContent.ItemType<SeraphBlade>();
        protected override int HelmetType => ModContent.ItemType<SeraphHelmet>();
        protected override int BodyType => ModContent.ItemType<SeraphBreastplate>();
        protected override int LegsType => ModContent.ItemType<SeraphLeggings>();
    }
}
