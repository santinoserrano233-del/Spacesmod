using Terraria.ID; using Terraria.ModLoader;
using SpaceMod.Content.Items;
using SpaceMod.Content.Items.Armor;
namespace SpaceMod.Content.NPCs.Bosses
{
    public class SatelliteGuardian : SpaceBoss
    {
        protected override int BaseLife => 9000;
        protected override int BaseDamage => 38;
        protected override int BaseDefense => 14;
        protected override int Size => 100;
        protected override float Speed => 12f;
        protected override int HealItem => ItemID.LesserHealingPotion;
        protected override string[] Attacks => new[] { "Spread", "Dash", "Spiral" };
        protected override int MaterialType => ModContent.ItemType<SatelliteCore>();
        protected override int WeaponType => ModContent.ItemType<SatelliteStaff>();
        protected override int HelmetType => ModContent.ItemType<SatelliteHelmet>();
        protected override int BodyType => ModContent.ItemType<SatelliteBreastplate>();
        protected override int LegsType => ModContent.ItemType<SatelliteLeggings>();
    }
}
