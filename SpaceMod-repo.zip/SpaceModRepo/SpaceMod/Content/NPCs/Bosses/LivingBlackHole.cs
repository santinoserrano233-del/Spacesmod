using Terraria.ID; using Terraria.ModLoader;
using SpaceMod.Content.Items;
using SpaceMod.Content.Items.Armor;
namespace SpaceMod.Content.NPCs.Bosses
{
    public class LivingBlackHole : SpaceBoss
    {
        protected override int BaseLife => 190000;
        protected override int BaseDamage => 160;
        protected override int BaseDefense => 50;
        protected override int Size => 140;
        protected override float Speed => 14f;
        protected override int HealItem => ItemID.SuperHealingPotion;
        protected override string[] Attacks => new[] { "Pull", "Spiral", "Ring" };
        protected override int MaterialType => ModContent.ItemType<SingularityShard>();
        protected override int WeaponType => ModContent.ItemType<SingularityStaff>();
        protected override int HelmetType => ModContent.ItemType<SingularityHelmet>();
        protected override int BodyType => ModContent.ItemType<SingularityBreastplate>();
        protected override int LegsType => ModContent.ItemType<SingularityLeggings>();
    }
}
