using Terraria.ID; using Terraria.ModLoader;
using SpaceMod.Content.Items;
using SpaceMod.Content.Items.Armor;
namespace SpaceMod.Content.NPCs.Bosses
{
    public class OrbitalColossus : SpaceBoss
    {
        protected override int BaseLife => 55000;
        protected override int BaseDamage => 90;
        protected override int BaseDefense => 32;
        protected override int Size => 130;
        protected override float Speed => 11f;
        protected override int HealItem => ItemID.GreaterHealingPotion;
        protected override string[] Attacks => new[] { "Ring", "Rain", "Dash" };
        protected override int MaterialType => ModContent.ItemType<ColossusPlating>();
        protected override int WeaponType => ModContent.ItemType<ColossusBlaster>();
        protected override int HelmetType => ModContent.ItemType<ColossusHelmet>();
        protected override int BodyType => ModContent.ItemType<ColossusBreastplate>();
        protected override int LegsType => ModContent.ItemType<ColossusLeggings>();
    }
}
