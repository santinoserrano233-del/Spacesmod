using Terraria.ID; using Terraria.ModLoader;
using SpaceMod.Content.Items;
using SpaceMod.Content.Items.Armor;
namespace SpaceMod.Content.NPCs.Bosses
{
    public class VoidDevourer : SpaceBoss
    {
        protected override int BaseLife => 320000;
        protected override int BaseDamage => 220;
        protected override int BaseDefense => 60;
        protected override int Size => 160;
        protected override float Speed => 18f;
        protected override int HealItem => ItemID.SuperHealingPotion;
        protected override string[] Attacks => new[] { "Pull", "Ring", "Spiral", "Rain", "Dash" };
        protected override int MaterialType => ModContent.ItemType<VoidEssence>();
        protected override int WeaponType => ModContent.ItemType<VoidStaff>();
        protected override int HelmetType => ModContent.ItemType<VoidHelmet>();
        protected override int BodyType => ModContent.ItemType<VoidBreastplate>();
        protected override int LegsType => ModContent.ItemType<VoidLeggings>();
    }
}
