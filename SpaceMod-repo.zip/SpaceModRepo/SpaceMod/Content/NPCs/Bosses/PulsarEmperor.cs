using Terraria.ID; using Terraria.ModLoader;
using SpaceMod.Content.Items;
using SpaceMod.Content.Items.Armor;
namespace SpaceMod.Content.NPCs.Bosses
{
    public class PulsarEmperor : SpaceBoss
    {
        protected override int BaseLife => 70000;
        protected override int BaseDamage => 100;
        protected override int BaseDefense => 35;
        protected override int Size => 110;
        protected override float Speed => 15f;
        protected override int HealItem => ItemID.GreaterHealingPotion;
        protected override string[] Attacks => new[] { "Spiral", "Rain", "Ring", "Dash" };
        protected override int MaterialType => ModContent.ItemType<PulsarCrystal>();
        protected override int WeaponType => ModContent.ItemType<PulsarBlade>();
        protected override int HelmetType => ModContent.ItemType<PulsarHelmet>();
        protected override int BodyType => ModContent.ItemType<PulsarBreastplate>();
        protected override int LegsType => ModContent.ItemType<PulsarLeggings>();
    }
}
