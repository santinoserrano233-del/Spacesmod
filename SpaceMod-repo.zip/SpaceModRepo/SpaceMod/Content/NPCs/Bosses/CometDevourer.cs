using Terraria.ID; using Terraria.ModLoader;
using SpaceMod.Content.Items;
using SpaceMod.Content.Items.Armor;
namespace SpaceMod.Content.NPCs.Bosses
{
    public class CometDevourer : SpaceBoss
    {
        protected override int BaseLife => 32000;
        protected override int BaseDamage => 70;
        protected override int BaseDefense => 25;
        protected override int Size => 110;
        protected override float Speed => 14f;
        protected override int HealItem => ItemID.GreaterHealingPotion;
        protected override string[] Attacks => new[] { "Dash", "Rain", "Spread", "Dash" };
        protected override int MaterialType => ModContent.ItemType<CometCore>();
        protected override int WeaponType => ModContent.ItemType<CometBlade>();
        protected override int HelmetType => ModContent.ItemType<CometHelmet>();
        protected override int BodyType => ModContent.ItemType<CometBreastplate>();
        protected override int LegsType => ModContent.ItemType<CometLeggings>();
    }
}
