using Terraria; using Terraria.ID; using Terraria.ModLoader; using Microsoft.Xna.Framework;
namespace SpaceMod.Content.Projectiles
{
    public class LunarBolt : ModProjectile
    {
        public override void SetDefaults()
        {
            Projectile.width = 16; Projectile.height = 16; Projectile.hostile = true; Projectile.friendly = false;
            Projectile.aiStyle = -1; Projectile.timeLeft = 300; Projectile.tileCollide = false; Projectile.penetrate = -1;
        }
        public override void AI()
        {
            Projectile.rotation = Projectile.velocity.ToRotation() + MathHelper.PiOver2;
            Lighting.AddLight(Projectile.Center, 0.4f, 0.5f, 0.9f);
            if (Main.rand.NextBool(3)) Dust.NewDust(Projectile.position, Projectile.width, Projectile.height, DustID.BlueTorch, 0f, 0f, 0, default, 1.2f);
        }
    }
}
