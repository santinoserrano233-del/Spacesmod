using Terraria; using Terraria.ID; using Terraria.ModLoader;
namespace SpaceMod.Content.Items
{
    public class ColossusBlaster : ModItem
    {
        public override void SetDefaults()
        {
            Item.width = 44; Item.height = 24; Item.DamageType = DamageClass.Ranged; Item.useTime = 12; Item.useAnimation = 12; Item.useStyle = ItemUseStyleID.Shoot; Item.noMelee = true; Item.knockBack = 3f; Item.UseSound = SoundID.Item11; Item.autoReuse = true; Item.shoot = ProjectileID.Bullet; Item.shootSpeed = 15f; Item.useAmmo = AmmoID.Bullet;
            Item.damage = 95; Item.rare = ItemRarityID.Lime; Item.value = Item.sellPrice(gold: 5);
        }
        public override void AddRecipes() { CreateRecipe().AddIngredient<ColossusPlating>(12).AddTile(TileID.MythrilAnvil).Register(); }
    }
}
