using Terraria; using Terraria.ID; using Terraria.ModLoader;
namespace SpaceMod.Content.Items
{
    public class PulsarBlade : ModItem
    {
        public override void SetDefaults()
        {
            Item.width = 44; Item.height = 44; Item.DamageType = DamageClass.Melee; Item.useTime = 22; Item.useAnimation = 22; Item.useStyle = ItemUseStyleID.Swing; Item.knockBack = 6f; Item.UseSound = SoundID.Item1; Item.autoReuse = true; Item.shoot = ProjectileID.TerraBeam; Item.shootSpeed = 14f;
            Item.damage = 110; Item.rare = ItemRarityID.Lime; Item.value = Item.sellPrice(gold: 5);
        }
        public override void AddRecipes() { CreateRecipe().AddIngredient<PulsarCrystal>(12).AddTile(TileID.MythrilAnvil).Register(); }
    }
}
