using Terraria; using Terraria.ID; using Terraria.ModLoader;
namespace SpaceMod.Content.Items.Armor
{
    [AutoloadEquip(EquipType.Head)]
    public class PulsarHelmet : ModItem
    {
        public override void SetDefaults()
        {
            Item.width = 28; Item.height = 24; Item.defense = 13; Item.rare = ItemRarityID.Lime; Item.value = Item.sellPrice(gold: 2);
        }
        public override void UpdateEquip(Player player) { player.GetCritChance(DamageClass.Melee) += 6; player.GetDamage(DamageClass.Melee) += 0.06f; }
        public override bool IsArmorSet(Item head, Item body, Item legs) => body.type == ModContent.ItemType<PulsarBreastplate>() && legs.type == ModContent.ItemType<PulsarLeggings>();
        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "+8% de dano y +15% de velocidad de movimiento";
            player.GetDamage(DamageClass.Generic) += 0.08f; player.moveSpeed += 0.15f;
        }
        public override void AddRecipes() { CreateRecipe().AddIngredient<PulsarCrystal>(10).AddTile(TileID.MythrilAnvil).Register(); }
    }
}
