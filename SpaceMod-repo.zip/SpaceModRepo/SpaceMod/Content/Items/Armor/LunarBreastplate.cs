using Terraria; using Terraria.ID; using Terraria.ModLoader;
namespace SpaceMod.Content.Items.Armor
{
    [AutoloadEquip(EquipType.Body)]
    public class LunarBreastplate : ModItem
    {
        public override void SetDefaults()
        {
            Item.width = 30; Item.height = 20; Item.defense = 8; Item.rare = ItemRarityID.Green; Item.value = Item.sellPrice(silver: 100);
        }
        public override void UpdateEquip(Player player) { player.statLifeMax2 += 40; }
        public override void AddRecipes() { CreateRecipe().AddIngredient<LunarFragment>(16).AddTile(TileID.Anvils).Register(); }
    }
}
