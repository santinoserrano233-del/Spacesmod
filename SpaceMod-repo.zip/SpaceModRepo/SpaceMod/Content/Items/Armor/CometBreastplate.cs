using Terraria; using Terraria.ID; using Terraria.ModLoader;
namespace SpaceMod.Content.Items.Armor
{
    [AutoloadEquip(EquipType.Body)]
    public class CometBreastplate : ModItem
    {
        public override void SetDefaults()
        {
            Item.width = 28; Item.height = 24; Item.defense = 17; Item.rare = ItemRarityID.LightRed; Item.value = Item.sellPrice(gold: 2);
        }
        public override void UpdateEquip(Player player) { player.statLifeMax2 += 100; }
        public override void AddRecipes() { CreateRecipe().AddIngredient<CometCore>(16).AddTile(TileID.MythrilAnvil).Register(); }
    }
}
