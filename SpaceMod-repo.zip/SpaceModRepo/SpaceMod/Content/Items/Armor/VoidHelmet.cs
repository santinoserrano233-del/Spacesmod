using Terraria; using Terraria.ID; using Terraria.ModLoader;
namespace SpaceMod.Content.Items.Armor
{
    [AutoloadEquip(EquipType.Head)]
    public class VoidHelmet : ModItem
    {
        public override void SetDefaults()
        {
            Item.width = 28; Item.height = 24; Item.defense = 21; Item.rare = ItemRarityID.Purple; Item.value = Item.sellPrice(gold: 2);
        }
        public override void UpdateEquip(Player player) { player.GetCritChance(DamageClass.Magic) += 4; player.GetDamage(DamageClass.Magic) += 0.06f; }
        public override bool IsArmorSet(Item head, Item body, Item legs) => body.type == ModContent.ItemType<VoidBreastplate>() && legs.type == ModContent.ItemType<VoidLeggings>();
        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "+16% de dano y +15% de velocidad de movimiento";
            player.GetDamage(DamageClass.Generic) += 0.16f; player.moveSpeed += 0.15f;
        }
        public override void AddRecipes() { CreateRecipe().AddIngredient<VoidEssence>(10).AddTile(TileID.LunarCraftingStation).Register(); }
    }
}
