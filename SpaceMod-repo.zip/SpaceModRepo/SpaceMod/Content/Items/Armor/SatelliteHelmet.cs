using Terraria; using Terraria.ID; using Terraria.ModLoader;
namespace SpaceMod.Content.Items.Armor
{
    [AutoloadEquip(EquipType.Head)]
    public class SatelliteHelmet : ModItem
    {
        public override void SetDefaults()
        {
            Item.width = 28; Item.height = 24; Item.defense = 6; Item.rare = ItemRarityID.Orange; Item.value = Item.sellPrice(gold: 2);
        }
        public override void UpdateEquip(Player player) { player.GetCritChance(DamageClass.Magic) += 5; player.GetDamage(DamageClass.Magic) += 0.06f; }
        public override bool IsArmorSet(Item head, Item body, Item legs) => body.type == ModContent.ItemType<SatelliteBreastplate>() && legs.type == ModContent.ItemType<SatelliteLeggings>();
        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "+10% de dano y +15% de velocidad de movimiento";
            player.GetDamage(DamageClass.Generic) += 0.1f; player.moveSpeed += 0.15f;
        }
        public override void AddRecipes() { CreateRecipe().AddIngredient<SatelliteCore>(10).AddTile(TileID.Anvils).Register(); }
    }
}
