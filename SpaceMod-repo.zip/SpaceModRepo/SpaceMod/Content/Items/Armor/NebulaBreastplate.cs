using Terraria; using Terraria.ID; using Terraria.ModLoader;
namespace SpaceMod.Content.Items.Armor
{
    [AutoloadEquip(EquipType.Body)]
    public class NebulaBreastplate : ModItem
    {
        public override void SetDefaults()
        {
            Item.width = 28; Item.height = 24; Item.defense = 18; Item.rare = ItemRarityID.Pink; Item.value = Item.sellPrice(gold: 2);
        }
        public override void UpdateEquip(Player player) { player.statLifeMax2 += 110; }
        public override void AddRecipes() { CreateRecipe().AddIngredient<NebulaEssence>(16).AddTile(TileID.MythrilAnvil).Register(); }
    }
}
