using Terraria; using Terraria.ID; using Terraria.ModLoader;
namespace SpaceMod.Content.Items.Armor
{
    [AutoloadEquip(EquipType.Head)]
    public class CometHelmet : ModItem
    {
        public override void SetDefaults()
        {
            Item.width = 28; Item.height = 24; Item.defense = 14; Item.rare = ItemRarityID.LightRed; Item.value = Item.sellPrice(gold: 2);
        }
        public override void UpdateEquip(Player player) { player.GetCritChance(DamageClass.Melee) += 6; player.GetDamage(DamageClass.Melee) += 0.06f; }
        public override bool IsArmorSet(Item head, Item body, Item legs) => body.type == ModContent.ItemType<CometBreastplate>() && legs.type == ModContent.ItemType<CometLeggings>();
        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "+12% de dano y +15% de velocidad de movimiento";
            player.GetDamage(DamageClass.Generic) += 0.12f; player.moveSpeed += 0.15f;
        }
        public override void AddRecipes() { CreateRecipe().AddIngredient<CometCore>(10).AddTile(TileID.MythrilAnvil).Register(); }
    }
}
