using Terraria; using Terraria.ID; using Terraria.ModLoader;
namespace SpaceMod.Content.Items.Armor
{
    [AutoloadEquip(EquipType.Body)]
    public class ColossusBreastplate : ModItem
    {
        public override void SetDefaults()
        {
            Item.width = 28; Item.height = 24; Item.defense = 15; Item.rare = ItemRarityID.Lime; Item.value = Item.sellPrice(gold: 2);
        }
        public override void UpdateEquip(Player player) { player.statLifeMax2 += 120; }
        public override void AddRecipes() { CreateRecipe().AddIngredient<ColossusPlating>(16).AddTile(TileID.MythrilAnvil).Register(); }
    }
}
