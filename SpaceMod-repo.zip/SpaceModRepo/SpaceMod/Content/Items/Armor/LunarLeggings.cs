using Terraria; using Terraria.ID; using Terraria.ModLoader;
namespace SpaceMod.Content.Items.Armor
{
    [AutoloadEquip(EquipType.Legs)]
    public class LunarLeggings : ModItem
    {
        public override void SetDefaults()
        {
            Item.width = 22; Item.height = 18; Item.defense = 6; Item.rare = ItemRarityID.Green; Item.value = Item.sellPrice(silver: 90);
        }
        public override void UpdateEquip(Player player) { player.moveSpeed += 0.1f; }
        public override void AddRecipes() { CreateRecipe().AddIngredient<LunarFragment>(12).AddTile(TileID.Anvils).Register(); }
    }
}
