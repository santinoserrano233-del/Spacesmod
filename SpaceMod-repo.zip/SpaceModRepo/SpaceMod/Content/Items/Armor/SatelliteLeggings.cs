using Terraria; using Terraria.ID; using Terraria.ModLoader;
namespace SpaceMod.Content.Items.Armor
{
    [AutoloadEquip(EquipType.Legs)]
    public class SatelliteLeggings : ModItem
    {
        public override void SetDefaults()
        {
            Item.width = 28; Item.height = 24; Item.defense = 7; Item.rare = ItemRarityID.Orange; Item.value = Item.sellPrice(gold: 2);
        }
        public override void UpdateEquip(Player player) { player.moveSpeed += 0.12f; player.GetCritChance(DamageClass.Generic) += 3; }
        public override void AddRecipes() { CreateRecipe().AddIngredient<SatelliteCore>(12).AddTile(TileID.Anvils).Register(); }
    }
}
