using Terraria; using Terraria.ID; using Terraria.ModLoader;
namespace SpaceMod.Content.Items.Armor
{
    [AutoloadEquip(EquipType.Body)]
    public class TitanBreastplate : ModItem
    {
        public override void SetDefaults()
        {
            Item.width = 28; Item.height = 24; Item.defense = 25; Item.rare = ItemRarityID.Cyan; Item.value = Item.sellPrice(gold: 2);
        }
        public override void UpdateEquip(Player player) { player.statLifeMax2 += 180; }
        public override void AddRecipes() { CreateRecipe().AddIngredient<TitanHeart>(16).AddTile(TileID.LunarCraftingStation).Register(); }
    }
}
