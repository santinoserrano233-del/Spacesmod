using Terraria; using Terraria.ID; using Terraria.ModLoader;
namespace SpaceMod.Content.Items.Armor
{
    [AutoloadEquip(EquipType.Legs)]
    public class NebulaLeggings : ModItem
    {
        public override void SetDefaults()
        {
            Item.width = 28; Item.height = 24; Item.defense = 16; Item.rare = ItemRarityID.Pink; Item.value = Item.sellPrice(gold: 2);
        }
        public override void UpdateEquip(Player player) { player.moveSpeed += 0.12f; player.GetCritChance(DamageClass.Generic) += 3; }
        public override void AddRecipes() { CreateRecipe().AddIngredient<NebulaEssence>(12).AddTile(TileID.MythrilAnvil).Register(); }
    }
}
