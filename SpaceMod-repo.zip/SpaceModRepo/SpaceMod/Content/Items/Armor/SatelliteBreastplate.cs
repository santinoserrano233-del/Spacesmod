using Terraria; using Terraria.ID; using Terraria.ModLoader;
namespace SpaceMod.Content.Items.Armor
{
    [AutoloadEquip(EquipType.Body)]
    public class SatelliteBreastplate : ModItem
    {
        public override void SetDefaults()
        {
            Item.width = 28; Item.height = 24; Item.defense = 9; Item.rare = ItemRarityID.Orange; Item.value = Item.sellPrice(gold: 2);
        }
        public override void UpdateEquip(Player player) { player.statLifeMax2 += 50; }
        public override void AddRecipes() { CreateRecipe().AddIngredient<SatelliteCore>(16).AddTile(TileID.Anvils).Register(); }
    }
}
