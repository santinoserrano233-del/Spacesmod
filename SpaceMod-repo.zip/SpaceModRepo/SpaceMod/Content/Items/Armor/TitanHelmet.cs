using Terraria; using Terraria.ID; using Terraria.ModLoader;
namespace SpaceMod.Content.Items.Armor
{
    [AutoloadEquip(EquipType.Head)]
    public class TitanHelmet : ModItem
    {
        public override void SetDefaults()
        {
            Item.width = 28; Item.height = 24; Item.defense = 22; Item.rare = ItemRarityID.Cyan; Item.value = Item.sellPrice(gold: 2);
        }
        public override void UpdateEquip(Player player) { player.GetCritChance(DamageClass.Ranged) += 4; player.GetDamage(DamageClass.Ranged) += 0.06f; }
        public override bool IsArmorSet(Item head, Item body, Item legs) => body.type == ModContent.ItemType<TitanBreastplate>() && legs.type == ModContent.ItemType<TitanLeggings>();
        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "+10% de dano y +15% de velocidad de movimiento";
            player.GetDamage(DamageClass.Generic) += 0.1f; player.moveSpeed += 0.15f;
        }
        public override void AddRecipes() { CreateRecipe().AddIngredient<TitanHeart>(10).AddTile(TileID.LunarCraftingStation).Register(); }
    }
}
