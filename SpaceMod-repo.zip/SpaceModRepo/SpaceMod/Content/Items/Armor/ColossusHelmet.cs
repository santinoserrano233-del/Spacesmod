using Terraria; using Terraria.ID; using Terraria.ModLoader;
namespace SpaceMod.Content.Items.Armor
{
    [AutoloadEquip(EquipType.Head)]
    public class ColossusHelmet : ModItem
    {
        public override void SetDefaults()
        {
            Item.width = 28; Item.height = 24; Item.defense = 12; Item.rare = ItemRarityID.Lime; Item.value = Item.sellPrice(gold: 2);
        }
        public override void UpdateEquip(Player player) { player.GetCritChance(DamageClass.Ranged) += 5; player.GetDamage(DamageClass.Ranged) += 0.06f; }
        public override bool IsArmorSet(Item head, Item body, Item legs) => body.type == ModContent.ItemType<ColossusBreastplate>() && legs.type == ModContent.ItemType<ColossusLeggings>();
        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "+16% de dano y +15% de velocidad de movimiento";
            player.GetDamage(DamageClass.Generic) += 0.16f; player.moveSpeed += 0.15f;
        }
        public override void AddRecipes() { CreateRecipe().AddIngredient<ColossusPlating>(10).AddTile(TileID.MythrilAnvil).Register(); }
    }
}
