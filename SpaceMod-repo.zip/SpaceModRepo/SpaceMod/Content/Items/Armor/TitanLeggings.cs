using Terraria; using Terraria.ID; using Terraria.ModLoader;
namespace SpaceMod.Content.Items.Armor
{
    [AutoloadEquip(EquipType.Legs)]
    public class TitanLeggings : ModItem
    {
        public override void SetDefaults()
        {
            Item.width = 28; Item.height = 24; Item.defense = 23; Item.rare = ItemRarityID.Cyan; Item.value = Item.sellPrice(gold: 2);
        }
        public override void UpdateEquip(Player player) { player.moveSpeed += 0.12f; player.GetCritChance(DamageClass.Generic) += 3; }
        public override void AddRecipes() { CreateRecipe().AddIngredient<TitanHeart>(12).AddTile(TileID.LunarCraftingStation).Register(); }
    }
}
