using Terraria; using Terraria.ID; using Terraria.ModLoader;
namespace SpaceMod.Content.Items.Armor
{
    [AutoloadEquip(EquipType.Body)]
    public class SeraphBreastplate : ModItem
    {
        public override void SetDefaults()
        {
            Item.width = 28; Item.height = 24; Item.defense = 23; Item.rare = ItemRarityID.Red; Item.value = Item.sellPrice(gold: 2);
        }
        public override void UpdateEquip(Player player) { player.statLifeMax2 += 200; }
        public override void AddRecipes() { CreateRecipe().AddIngredient<SeraphFeather>(16).AddTile(TileID.LunarCraftingStation).Register(); }
    }
}
