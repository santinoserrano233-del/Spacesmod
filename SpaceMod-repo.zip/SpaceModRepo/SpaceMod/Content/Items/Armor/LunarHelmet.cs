using Terraria; using Terraria.ID; using Terraria.ModLoader;
namespace SpaceMod.Content.Items.Armor
{
    [AutoloadEquip(EquipType.Head)]
    public class LunarHelmet : ModItem
    {
        public override void SetDefaults()
        {
            Item.width = 24; Item.height = 24; Item.defense = 6; Item.rare = ItemRarityID.Green; Item.value = Item.sellPrice(silver: 80);
        }
        public override void UpdateEquip(Player player) { player.GetCritChance(DamageClass.Generic) += 6; }
        public override bool IsArmorSet(Item head, Item body, Item legs) => body.type == ModContent.ItemType<LunarBreastplate>() && legs.type == ModContent.ItemType<LunarLeggings>();
        public override void UpdateArmorSet(Player player)
        {
            player.setBonus = "+12% de daño y +20% de velocidad de movimiento";
            player.GetDamage(DamageClass.Generic) += 0.12f; player.moveSpeed += 0.2f;
        }
        public override void AddRecipes() { CreateRecipe().AddIngredient<LunarFragment>(10).AddTile(TileID.Anvils).Register(); }
    }
}
