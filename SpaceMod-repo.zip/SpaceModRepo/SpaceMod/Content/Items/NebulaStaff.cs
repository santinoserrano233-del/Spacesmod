using Terraria; using Terraria.ID; using Terraria.ModLoader;
namespace SpaceMod.Content.Items
{
    public class NebulaStaff : ModItem
    {
        public override void SetDefaults()
        {
            Item.width = 40; Item.height = 40; Item.DamageType = DamageClass.Magic; Item.mana = 9; Item.useTime = 16; Item.useAnimation = 16; Item.useStyle = ItemUseStyleID.Shoot; Item.noMelee = true; Item.knockBack = 4f; Item.UseSound = SoundID.Item43; Item.autoReuse = true; Item.shoot = ProjectileID.LaserMachinegunLaser; Item.shootSpeed = 16f;
            Item.damage = 85; Item.rare = ItemRarityID.Pink; Item.value = Item.sellPrice(gold: 5);
        }
        public override void AddRecipes() { CreateRecipe().AddIngredient<NebulaEssence>(12).AddTile(TileID.MythrilAnvil).Register(); }
    }
}
