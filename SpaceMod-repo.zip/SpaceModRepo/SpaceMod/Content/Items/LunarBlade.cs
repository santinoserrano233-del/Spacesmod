using Terraria; using Terraria.ID; using Terraria.ModLoader;
namespace SpaceMod.Content.Items
{
    public class LunarBlade : ModItem
    {
        public override void SetDefaults()
        {
            Item.width = 40; Item.height = 40; Item.damage = 28; Item.DamageType = DamageClass.Melee;
            Item.useTime = 22; Item.useAnimation = 22; Item.useStyle = ItemUseStyleID.Swing;
            Item.knockBack = 5f; Item.value = Item.sellPrice(gold: 1); Item.rare = ItemRarityID.Green;
            Item.UseSound = SoundID.Item1; Item.autoReuse = true;
            Item.shoot = ProjectileID.EnchantedBeam; Item.shootSpeed = 10f;
        }
        public override void AddRecipes()
        {
            CreateRecipe().AddIngredient<LunarFragment>(12).AddTile(TileID.Anvils).Register();
        }
    }
}
