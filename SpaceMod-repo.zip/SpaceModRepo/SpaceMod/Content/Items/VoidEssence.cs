using Terraria; using Terraria.ID; using Terraria.ModLoader;
namespace SpaceMod.Content.Items
{
    public class VoidEssence : ModItem
    {
        public override void SetStaticDefaults() { Item.ResearchUnlockCount = 25; }
        public override void SetDefaults()
        {
            Item.width = 32; Item.height = 32; Item.maxStack = Item.CommonMaxStack;
            Item.value = Item.sellPrice(silver: 80); Item.rare = ItemRarityID.Purple;
        }
    }
}
