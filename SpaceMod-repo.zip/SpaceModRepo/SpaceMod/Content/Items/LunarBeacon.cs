using Terraria; using Terraria.Audio; using Terraria.ID; using Terraria.ModLoader;
using SpaceMod.Content.NPCs.Bosses;
namespace SpaceMod.Content.Items
{
    public class LunarBeacon : ModItem
    {
        public override void SetStaticDefaults() { Item.ResearchUnlockCount = 3; ItemID.Sets.SortingPriorityBossSpawns[Type] = 12; }
        public override void SetDefaults()
        {
            Item.width = 32; Item.height = 32; Item.maxStack = Item.CommonMaxStack;
            Item.useAnimation = 30; Item.useTime = 30; Item.useStyle = ItemUseStyleID.HoldUp;
            Item.consumable = true; Item.rare = ItemRarityID.Blue; Item.value = Item.sellPrice(silver: 10);
        }
        public override bool CanUseItem(Player player) => !Main.dayTime && !NPC.AnyNPCs(ModContent.NPCType<LunarSentinel>());
        public override bool? UseItem(Player player)
        {
            if (player.whoAmI == Main.myPlayer)
            {
                SoundEngine.PlaySound(SoundID.Roar, player.position);
                int type = ModContent.NPCType<LunarSentinel>();
                if (Main.netMode != NetmodeID.MultiplayerClient) NPC.SpawnOnPlayer(player.whoAmI, type);
                else NetMessage.SendData(MessageID.SpawnBossUseLicenseStartEvent, number: player.whoAmI, number2: type);
            }
            return true;
        }
        public override void AddRecipes()
        {
            CreateRecipe().AddRecipeGroup(RecipeGroupID.IronBar, 5).AddIngredient(ItemID.FallenStar, 5)
                .AddTile(TileID.Anvils).Register();
        }
    }
}
