using Terraria; using Terraria.Audio; using Terraria.ID; using Terraria.ModLoader;
using SpaceMod.Content.NPCs.Bosses;
namespace SpaceMod.Content.Items
{
    public class SatelliteBeacon : ModItem
    {
        public override void SetStaticDefaults() { Item.ResearchUnlockCount = 3; ItemID.Sets.SortingPriorityBossSpawns[Type] = 12; }
        public override void SetDefaults()
        {
            Item.width = 32; Item.height = 32; Item.maxStack = Item.CommonMaxStack;
            Item.useAnimation = 30; Item.useTime = 30; Item.useStyle = ItemUseStyleID.HoldUp;
            Item.consumable = true; Item.rare = ItemRarityID.Orange; Item.value = Item.sellPrice(silver: 50);
        }
        public override bool CanUseItem(Player player) => true && !NPC.AnyNPCs(ModContent.NPCType<SatelliteGuardian>());
        public override bool? UseItem(Player player)
        {
            if (player.whoAmI == Main.myPlayer)
            {
                SoundEngine.PlaySound(SoundID.Roar, player.position);
                int type = ModContent.NPCType<SatelliteGuardian>();
                if (Main.netMode != NetmodeID.MultiplayerClient) NPC.SpawnOnPlayer(player.whoAmI, type);
                else NetMessage.SendData(MessageID.SpawnBossUseLicenseStartEvent, number: player.whoAmI, number2: type);
            }
            return true;
        }
        public override void AddRecipes()
        {
            CreateRecipe().AddIngredient<AsteroidShard>(6).AddRecipeGroup(RecipeGroupID.IronBar, 10).AddTile(TileID.Anvils).Register();
        }
    }
}
