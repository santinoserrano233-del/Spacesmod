using Terraria; using Terraria.ID; using Terraria.ModLoader;
namespace SpaceMod.Content.Items
{
    public class AsteroidBlaster : ModItem
    {
        public override void SetDefaults()
        {
            Item.width = 44; Item.height = 24; Item.DamageType = DamageClass.Ranged; Item.useTime = 12; Item.useAnimation = 12; Item.useStyle = ItemUseStyleID.Shoot; Item.noMelee = true; Item.knockBack = 3f; Item.UseSound = SoundID.Item11; Item.autoReuse = true; Item.shoot = ProjectileID.Bullet; Item.shootSpeed = 15f; Item.useAmmo = AmmoID.Bullet;
            Item.damage = 26; Item.rare = ItemRarityID.Orange; Item.value = Item.sellPrice(gold: 5);
        }
        public override void AddRecipes() { CreateRecipe().AddIngredient<AsteroidShard>(12).AddTile(TileID.Anvils).Register(); }
    }
}
