using Terraria.ModLoader;
namespace SpaceMod { public class SpaceMod : Mod { } }
